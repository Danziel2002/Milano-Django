from django.contrib import admin
from .models import publicTransportVehicle

admin.site.register(publicTransportVehicle)