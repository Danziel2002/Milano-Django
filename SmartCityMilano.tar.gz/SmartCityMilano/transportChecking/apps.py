from django.apps import AppConfig


class TransportcheckingConfig(AppConfig):
    name = 'transportChecking'
