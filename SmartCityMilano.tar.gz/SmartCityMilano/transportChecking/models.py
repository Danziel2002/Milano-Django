from django.db import models


class publicTransportVehicle(models.Model):
	nameOfTheVehicle = models.CharField(max_length = 10)
	priceOfTheRide = models.IntegerField()