from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

class profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    level = models.IntegerField()
    exp = models.IntegerField()

    def levelUp(self):
        self.level += 1
        exp -= 100

    def expGet(self, expEarned):
        self.exp += expEarned
        if self.exp > 100:
            levelUp()

