from django.apps import AppConfig


class UseraccountregisterandloginConfig(AppConfig):
    name = 'UserAccountRegisterAndLogin'
