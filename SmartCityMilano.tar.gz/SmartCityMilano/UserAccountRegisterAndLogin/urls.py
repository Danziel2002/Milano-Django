from django.urls import path
from . import views, functionViews


urlpatterns = [
    path('registerUserAccount/', views.registerUserAccount),
    path('loginUserAccount/', views.loginUserAccount),
    path('registerUserForWebsite', functionViews.registerUserForWebsite),
]

