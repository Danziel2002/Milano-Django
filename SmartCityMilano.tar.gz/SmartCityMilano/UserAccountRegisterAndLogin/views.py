from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.

def registerUserAccount(req):
	return render(req, 'UserAccountRegisterAndLogin/registerUserAccount.html')

def loginUserAccount(req):
	return render(req, 'UserAccountRegisterAndLogin/loginUserAccount.html')