from django.contrib.auth.models import User
from django.http import HttpResponse

def registerUserForWebsite(req):
	usernameOfUser = req.GET.get('username')
	passwordOfUser = req.GET.get('password')
	emailOfUser = req.GET.get('email')

	newUser = User(usernameOfUser, emailOfUser, passwordOfUser)
	return HttpResponse("Good")
