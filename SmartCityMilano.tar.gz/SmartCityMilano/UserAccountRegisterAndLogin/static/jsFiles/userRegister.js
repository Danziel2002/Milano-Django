$(document).ready(function (){

	$('.submitRegisterForum').click(function(){

		if($('.usernameInput').val() != "" && $('.emailInput').val() != "" && $('.passwordInput').val() == $('.confirmPasswordInput').val() && $('.passwordInput').val() != ''){

			    $.ajax({
			        url : '/account/registerUserForWebsite?username=' + $('.usernameInput').val() +  "&password=" + $('.passwordInput').val() + "&email=" + $('.emailInput').val()
			    });}
		else{
			console.log($('.usernameInput').val());
		}

	});

});