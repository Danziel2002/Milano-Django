from django.apps import AppConfig


class InformativepagesConfig(AppConfig):
    name = 'InformativePages'
