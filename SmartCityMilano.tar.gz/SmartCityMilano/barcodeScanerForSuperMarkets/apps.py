from django.apps import AppConfig


class BarcodescanerforsupermarketsConfig(AppConfig):
    name = 'barcodeScanerForSuperMarkets'
